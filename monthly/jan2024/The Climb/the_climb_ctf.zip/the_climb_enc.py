import numpy as np

def encrypt_cipher(message, key_matrix):
    message = ''.join(char.upper() for char in message)

    while len(message) % len(key_matrix) != 0:
        message += 'Z'

    message_matrix = np.array([ord(char) - ord('A') for char in message])
    message_matrix = message_matrix.reshape(-1, len(key_matrix))

    encrypted_matrix = (message_matrix @ key_matrix) % 26

    encrypted_message = ''
    for i in range(message_matrix.shape[0]):
        for j in range(message_matrix.shape[1]):
            char = message[i * len(key_matrix) + j]
            encrypted_char = chr(encrypted_matrix[i, j] + ord('A')) if char.isalpha() else char
            encrypted_message += encrypted_char

    return encrypted_message

encrypted_message = encrypt_cipher(message, key_matrix)
print("Encrypted Message:", encrypted_message)
